"""Test the backends of the visualization package."""

import random
import types
from typing import ClassVar
from unittest.mock import MagicMock

import numpy as np
import pytest

from mesa import Model
from mesa.discrete_space.grid import OrthogonalMooreGrid
from mesa.experimental.continuous_space import ContinuousSpace, ContinuousSpaceAgent
from mesa.visualization.backends import AltairBackend, MatplotlibBackend
from mesa.visualization.components import AgentPortrayalStyle, PropertyLayerStyle


@pytest.mark.parametrize("backend_cls", [MatplotlibBackend, AltairBackend])
def test_backend_get_agent_pos_raises_when_position_too_short(backend_cls):
    """Backends should reject agent positions with fewer than 2 coordinates."""
    backend = backend_cls(space_drawer=MagicMock())

    class DummySpace:
        viz_dims = (0, 1)

    class DummyAgent:
        position = (0.1,)

    with pytest.raises(ValueError, match="at least 2 dimensions"):
        backend._get_agent_pos(DummyAgent(), DummySpace())


def test_matplotlib_initialize_canvas():
    """Test that MatplotlibBackend initializes canvas with ax and fig."""
    mb = MatplotlibBackend(space_drawer=MagicMock())
    mb.initialize_canvas()
    assert mb.ax is not None
    assert mb.fig is not None


def test_matplotlib_initialize_canvas_with_custom_ax():
    """Test initializing canvas with a provided ax skips creating fig."""
    mb = MatplotlibBackend(space_drawer=MagicMock())
    ax = MagicMock()
    mb.initialize_canvas(ax=ax)
    assert mb.ax == ax
    assert not hasattr(mb, "fig")


def test_matplotlib_backend_draw_structure(monkeypatch):
    """Test draw_structure returns ax from draw_matplotlib."""
    mb = MatplotlibBackend(space_drawer=MagicMock())
    mb.initialize_canvas()
    ax = MagicMock()
    monkeypatch.setattr(mb, "ax", ax)
    mb.space_drawer.draw_matplotlib = MagicMock(return_value=ax)
    assert mb.draw_structure() == ax


def test_matplotlib_backend_collects_agent_data():
    """Test collect_agent_data."""
    mb = MatplotlibBackend(space_drawer=MagicMock())

    class DummyAgent:
        position = (0, 0)
        cell = types.SimpleNamespace(coordinate=(0, 0))

    class DummySpace:
        agents: ClassVar[list] = [DummyAgent()]

    # Test with AgentPortrayalStyle
    def agent_portrayal_style(agent):
        return AgentPortrayalStyle(
            x=0,
            y=0,
            size=5,
            color="red",
            marker="o",
            zorder=1,
            alpha=1.0,
            edgecolors="black",
            linewidths=1,
        )

    data = mb.collect_agent_data(DummySpace(), agent_portrayal_style)
    assert "loc" in data and data["loc"].shape[0] == 1

    # Test with dict-based portrayal (deprecated, emits FutureWarning)
    def agent_portrayal_dict(agent):
        return {"size": 5, "color": "red", "marker": "o"}

    with pytest.warns(FutureWarning):
        data = mb.collect_agent_data(DummySpace(), agent_portrayal_dict)

    assert "loc" in data and data["loc"].shape[0] == 1


def test_matplotlib_backend_draw_agents():
    """Test drawing agents."""
    mb = MatplotlibBackend(space_drawer=MagicMock())
    mb.initialize_canvas()

    # Test with empty data
    arguments = {"loc": np.array([]), "marker": np.array([]), "zorder": np.array([])}
    result = mb.draw_agents(arguments)
    assert result is None

    # Test with data
    arguments = {
        "loc": np.array([[0, 0], [1, 1]]),
        "marker": np.array(["o", "s"]),
        "zorder": np.array([1, 1]),
        "s": np.array([5, 5]),
        "c": np.array(["red", "blue"]),
        "alpha": np.array([1.0, 1.0]),
        "edgecolors": np.array(["black", "black"]),
        "linewidths": np.array([1, 1]),
    }
    result = mb.draw_agents(arguments)
    assert result == mb.ax


def test_matplotlib_backend_draw_agents_bad_marker(monkeypatch):
    """Test drawing agents with nonexistent marker file raises ValueError."""
    mb = MatplotlibBackend(space_drawer=MagicMock())
    mb.initialize_canvas()
    monkeypatch.setattr("os.path.isfile", lambda path: False)
    arguments = {
        "loc": np.array([[0, 0]]),
        "marker": np.array(["notafile.png"], dtype=object),
        "zorder": np.array([1]),
        "s": np.array([1]),
        "c": np.array(["red"]),
        "alpha": np.array([1.0]),
        "edgecolors": np.array(["black"]),
        "linewidths": np.array([1]),
    }
    with pytest.raises(ValueError):
        mb.draw_agents(arguments.copy())


def test_matplotlib_backend_draw_property():
    """Test drawing property layer."""
    # Test with color
    mb = MatplotlibBackend(space_drawer=MagicMock())
    mb.initialize_canvas()

    # set up space and layer
    space = OrthogonalMooreGrid([2, 2], random=random.Random(42))
    space.create_property_layer("test", default_value=0.0)

    result = mb.draw_property_layer(
        space,
        space.property_layers,
        lambda l: PropertyLayerStyle(  # noqa: E741
            color="red", alpha=0.5, vmin=0, vmax=1, colorbar=False
        ),
    )
    assert result[0] == mb.ax
    assert result[1] is None

    result = mb.draw_property_layer(
        space,
        space.property_layers,
        lambda l: PropertyLayerStyle(  # noqa: E741
            colormap="viridis", alpha=0.5, vmin=0, vmax=1, colorbar=True
        ),
    )
    assert result[0] == mb.ax
    assert result[1] is not None

    with pytest.raises(ValueError, match="Specify one of 'color' or 'colormap'"):
        mb.draw_property_layer(
            space,
            space.property_layers,
            lambda l: PropertyLayerStyle(  # noqa: E741
                color=None, colormap=None, alpha=1.0, vmin=0, vmax=1, colorbar=False
            ),
        )


def test_altair_backend_draw_structure():
    """Test AltairBackend draw_structure returns chart."""
    ab = AltairBackend(space_drawer=MagicMock())
    ab.space_drawer.draw_altair = MagicMock(return_value="chart")
    assert ab.draw_structure() == "chart"


def test_altair_backend_collects_agent_data():
    """Test collect_agent_data."""
    ab = AltairBackend(space_drawer=MagicMock())

    class DummyAgent:
        position = (0, 0)
        cell = types.SimpleNamespace(coordinate=(0, 0))

    class DummySpace:
        agents: ClassVar[list] = [DummyAgent()]

    # Test with AgentPortrayalStyle
    def agent_portrayal_style(agent):
        return AgentPortrayalStyle(
            x=0,
            y=0,
            size=5,
            color="red",
            marker="o",
            zorder=1,
            alpha=1.0,
            edgecolors="black",
            linewidths=1,
        )

    data = ab.collect_agent_data(DummySpace(), agent_portrayal_style)
    assert "loc" in data and data["loc"].shape[0] == 1

    # Test with dict-based portrayal (deprecated, emits FutureWarning)
    def agent_portrayal_dict(agent):
        return {"size": 5, "color": "red", "marker": "o"}

    with pytest.warns(FutureWarning):
        data = ab.collect_agent_data(DummySpace(), agent_portrayal_dict)

    assert "loc" in data and data["loc"].shape[0] == 1


def test_altair_backend_collects_agent_data_marker_mapping():
    """Test collect_agent_data maps markers to Altair shapes."""
    ab = AltairBackend(space_drawer=MagicMock())

    class DummyAgent:
        pos = (0, 0)
        cell = types.SimpleNamespace(coordinate=(0, 0))

    class DummySpace:
        agents: ClassVar[list] = [DummyAgent()]

    def agent_portrayal(agent):
        return AgentPortrayalStyle(
            x=0, y=0, size=5, color="red", marker="s", zorder=1, alpha=1.0
        )

    data = ab.collect_agent_data(DummySpace(), agent_portrayal)
    assert data["shape"][0] == "square"


def test_altair_backend_draw_agents():
    """Test draw_agents."""
    # Test with empty data
    ab = AltairBackend(space_drawer=MagicMock())
    result = ab.draw_agents({"loc": np.array([])})
    assert result is None

    # Test with data
    arguments = {
        "loc": np.array([[0, 0], [1, 1]]),
        "size": np.array([5, 5]),
        "shape": np.array(["circle", "square"]),
        "opacity": np.array([1.0, 1.0]),
        "strokeWidth": np.array([1, 1]),
        "color": np.array(["red", "blue"]),
        "filled": np.array([True, True]),
        "stroke": np.array(["black", "black"]),
        "tooltip": np.array([None, None]),
    }
    ab.space_drawer.get_viz_limits = MagicMock(return_value=(0, 10, 0, 10))
    assert ab.draw_agents(arguments) is not None


def test_altair_backend_draw_property_layer():
    """Test drawing property_layer."""
    ab = AltairBackend(space_drawer=MagicMock())

    space = OrthogonalMooreGrid([2, 2], random=random.Random(42))
    space.create_property_layer("test", default_value=0.0)

    assert (
        ab.draw_property_layer(
            space,
            space.property_layers,
            lambda l: PropertyLayerStyle(  # noqa: E741
                color="red", alpha=0.5, vmin=0, vmax=1, colorbar=False
            ),
        )
        is not None
    )

    assert (
        ab.draw_property_layer(
            space,
            space.property_layers,
            lambda l: PropertyLayerStyle(  # noqa: E741
                colormap="viridis", alpha=0.5, vmin=0, vmax=1, colorbar=True
            ),
        )
        is not None
    )

    with pytest.raises(ValueError, match="Specify one of 'color' or 'colormap'"):
        ab.draw_property_layer(
            space,
            space.property_layers,
            lambda l: PropertyLayerStyle(  # noqa: E741
                color=None, colormap=None, alpha=1.0, vmin=0, vmax=1, colorbar=False
            ),
        )


def test_backend_get_agent_pos():
    """Test extracting agent position from pos and cell.coordinate attributes."""
    mb = MatplotlibBackend(space_drawer=MagicMock())

    class AgentWithPos:
        position = (1, 2)

    x, y = mb._get_agent_pos(AgentWithPos(), None)
    assert (x, y) == (1, 2)

    class AgentWithCell:
        position = (3, 4)
        cell = types.SimpleNamespace(coordinate=(3, 4))

    x, y = mb._get_agent_pos(AgentWithCell(), None)
    assert (x, y) == (3, 4)


def test_backend_get_agent_pos_uses_space_drawer_viz_dims():
    """Backends should project continuous positions using the space drawer's viz_dims."""
    mb = MatplotlibBackend(space_drawer=types.SimpleNamespace(viz_dims=(0, 2)))

    class DummyAgent:
        position = (0.1, 0.2, 0.3)

    x, y = mb._get_agent_pos(DummyAgent(), None)
    assert (x, y) == (0.1, 0.3)


def test_backend_get_agent_pos_raises_when_viz_dims_out_of_range():
    """Backends should raise a helpful error when viz_dims do not match the position."""
    mb = MatplotlibBackend(space_drawer=types.SimpleNamespace(viz_dims=(0, 2)))

    class DummyAgent:
        position = (0.1, 0.2)

    with pytest.raises(ValueError, match="not have enough dimensions"):
        mb._get_agent_pos(DummyAgent(), None)


@pytest.mark.parametrize("backend_cls", [MatplotlibBackend, AltairBackend])
def test_backend_collect_agent_data_projects_3d_continuous_positions(backend_cls):
    """Test collect_agent_data projects nD continuous positions onto viz_dims."""
    backend = backend_cls(space_drawer=MagicMock())
    model = Model(rng=42)
    space = ContinuousSpace(
        dimensions=np.array([[0, 1], [0, 1], [0, 1]]),
        torus=False,
        random=model.random,
    )

    agent_1 = ContinuousSpaceAgent(space, model)
    agent_1.position = [0.1, 0.2, 0.3]
    agent_2 = ContinuousSpaceAgent(space, model)
    agent_2.position = [0.4, 0.5, 0.6]

    def agent_portrayal(agent):
        return AgentPortrayalStyle(
            x=None,
            y=None,
            size=5,
            color="red",
            marker="o",
            zorder=1,
            alpha=1.0,
            edgecolors="black",
            linewidths=1,
        )

    data = backend.collect_agent_data(space, agent_portrayal)

    assert data["loc"].shape == (2, 2)
    np.testing.assert_allclose(data["loc"][:, 0], [0.1, 0.4])
    np.testing.assert_allclose(data["loc"][:, 1], [0.2, 0.5])


@pytest.mark.parametrize("backend_cls", [MatplotlibBackend, AltairBackend])
def test_backend_collect_agent_data_warns_once_for_dict_portrayal(backend_cls):
    """The dict portrayal FutureWarning is emitted once per call, not per agent."""
    backend = backend_cls(space_drawer=MagicMock())

    class DummyAgent:
        position = (0, 0)
        cell = types.SimpleNamespace(coordinate=(0, 0))

    class DummySpace:
        agents: ClassVar[list] = [DummyAgent() for _ in range(5)]

    def agent_portrayal_dict(agent):
        return {"size": 5, "color": "red", "marker": "o"}

    with pytest.warns(FutureWarning) as record:
        data = backend.collect_agent_data(DummySpace(), agent_portrayal_dict)

    assert len([w for w in record if issubclass(w.category, FutureWarning)]) == 1
    assert data["loc"].shape[0] == 5


def test_backends_handle_errors():
    """Test error handling scenarios for invalid agent/property_layer data."""
    mb = MatplotlibBackend(space_drawer=MagicMock())
    mb.initialize_canvas()
    arguments = {
        "loc": np.array([[0, 0]]),
        "marker": np.array(["o"]),
        "zorder": np.array([1]),
        "s": np.array([5]),
        "c": np.array(["red"]),
        "alpha": np.array([1.0]),
        "edgecolors": np.array(["black"]),
        "linewidths": np.array([1]),
    }
    with pytest.raises(ValueError):
        mb.draw_agents(arguments, edgecolors="blue")

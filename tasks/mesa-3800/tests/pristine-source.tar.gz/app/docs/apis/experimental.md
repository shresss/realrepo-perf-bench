# Experimental
This namespace contains experimental features. These are under development, and their API is not necessarily stable.

## Continuous Space

```{eval-rst}
.. automodule:: experimental.continuous_space.continuous_space
   :members:
```

```{eval-rst}
.. automodule:: experimental.continuous_space.continuous_space_agents
   :members:
```

## Continuous Space

```{eval-rst}
.. automodule:: experimental.continuous_space.continuous_space
   :members:
```

```{eval-rst}
.. automodule:: experimental.continuous_space.continuous_space_agents
   :members:
```

## Scenarios

```{eval-rst}
.. automodule:: experimental.scenarios.scenario
   :members:
```

```{eval-rst}
.. automodule:: experimental.scenarios.runner
   :members:
```
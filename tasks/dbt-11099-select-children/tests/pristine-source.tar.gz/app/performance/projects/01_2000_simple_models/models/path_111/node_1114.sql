select 1 as id
union all
select * from {{ ref('node_0') }}
union all
select * from {{ ref('node_3') }}
union all
select * from {{ ref('node_6') }}
union all
select * from {{ ref('node_8') }}
union all
select * from {{ ref('node_10') }}
union all
select * from {{ ref('node_48') }}
union all
select * from {{ ref('node_67') }}
union all
select * from {{ ref('node_72') }}
union all
select * from {{ ref('node_75') }}
union all
select * from {{ ref('node_104') }}
union all
select * from {{ ref('node_146') }}
union all
select * from {{ ref('node_368') }}
union all
select * from {{ ref('node_461') }}
union all
select * from {{ ref('node_592') }}
union all
select * from {{ ref('node_870') }}

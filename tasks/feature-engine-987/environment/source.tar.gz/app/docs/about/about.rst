.. -*- mode: rst -*-

About
=====

History
-------

Data scientists spend a huge amount of time on data pre-processing and transformation.
It would be great (we thought back in the day) to gather the most frequently used data
pre-processing techniques and transformations in a library, from which we could pick
and choose the transformation that we need, and use it just like we would use any other
sklearn class. This was the original vision for feature-engine.

Feature-engine is an open source Python package originally designed to support the online
course `Feature Engineering for Machine Learning <https://courses.trainindata.com/p/feature-engineering-for-machine-learning>`_,
but has now gained popularity and supports transformations beyond those taught in the
course. It was launched in 2017, and since then, several releases have appeared and a
growing international community is beginning to lead the development.

Governance
----------

The decision making process and governance structure of feature-engine is laid out in
the :ref:`**governance document** <governance>`.

Core contributors
-----------------

The following people are currently core contributors to feature-engine’s development
and maintenance:

.. include:: authors.rst


Former core contributors
------------------------

The following people are former core contributors to feature-engine’s development
and maintenance:

.. include:: former_authors.rst

Contributors
------------

.. image:: https://img.shields.io/github/contributors/feature-engine/feature_engine?logo=GitHub
   :target: https://github.com/feature-engine/feature_engine/graphs/contributors

|

A growing international community is beginning to lead feature-engine's development.
You can learn more about feature-engine's Contributors in the
`GitHub contributors page <https://github.com/feature-engine/feature_engine/graphs/contributors>`_.

Citing feature-engine
---------------------

.. image:: https://zenodo.org/badge/163630824.svg
   :target: https://zenodo.org/badge/latestdoi/163630824

.. image:: https://joss.theoj.org/papers/10.21105/joss.03642/status.svg
   :target: https://joss.theoj.org/papers/10.21105/joss.03642

|

If you use feature-engine in a scientific publication, you can cite the following paper:
Galli, S., (2021). `feature-engine: A Python package for feature engineering for machine learning. <https://joss.theoj.org/papers/10.21105/joss.03642>`_
Journal of Open Source Software, 6(65), 3642.

Bibtex entry:

.. code-block:: bibtex

    @article{Galli2021,
    doi = {10.21105/joss.03642},
    url = {https://doi.org/10.21105/joss.03642},
    year = {2021},
    publisher = {The Open Journal},
    volume = {6},
    number = {65},
    pages = {3642},
    author = {Soledad Galli},
    title = {feature-engine: A Python package for feature engineering for machine learning},
    journal = {Journal of Open Source Software}
    }



You can also find a DOI (digital object identifier) for every version of feature-engine
on `zenodo.org <https://zenodo.org/badge/latestdoi/163630824>`_; use the BibTeX on this
site to reference specific versions of the software.


Artwork
-------

High quality PNG and SVG logos are available in the `docs/images/ <https://github.com/feature-engine/feature_engine/tree/main/docs/images/logo>`_
source directory of the repository.

.. figure::  ../images/logo/FeatureEngine.png
   :width: 200
   :figclass: align-center
   :align: center

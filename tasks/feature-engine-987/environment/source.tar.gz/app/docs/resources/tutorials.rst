Tutorials
=========

How To
------

Check our `jupyter notebooks <https://nbviewer.jupyter.org/github/feature-engine/feature-engine-examples/tree/main/>`_
showcasing the functionality of each feature-engine transformer.

Kaggle Kernels
--------------

We also prepared Kaggle kernels with demos mixing data exploration, feature engineering,
feature creation, feature selection and hyperparameter optimisation of entire pipelines.

- `Feature selection for bank customer satisfaction prediction <https://www.kaggle.com/solegalli/feature-selection-with-feature-engine>`_
- `Feature engineering and selection for house price prediction <https://www.kaggle.com/solegalli/predict-house-price-with-feature-engine>`_
- `Feature creation for wine quality prediction <https://www.kaggle.com/solegalli/create-new-features-with-feature-engine>`_
- `Feature engineering and model stacking for house price modelling <https://www.kaggle.com/solegalli/feature-engineering-and-model-stacking>`_
- `Feature engineering with feature-engine and Randomized search <https://www.kaggle.com/solegalli/feature-engineering-with-randomized-search>`_
- `Feature engineering with feature-engine and Grid search <https://www.kaggle.com/solegalli/feature-engineering-pipeline-and-hyperparam-tuning>`_



Video tutorials
---------------

You can find some videos on how to use feature-engine in the
`feature-engine playlist <https://www.youtube.com/playlist?list=PL_7uaHXkQmKVlqlvgQJuaWEKjagHbERtp>`_
in Train in Data's YouTube channel. The list is a bit short at the moment, apologies.
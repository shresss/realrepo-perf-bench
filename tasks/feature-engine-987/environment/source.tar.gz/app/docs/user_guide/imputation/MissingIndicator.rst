.. _add_missing_indicator:

.. currentmodule:: feature_engine.imputation

MissingIndicator
================


The :class:`MissingIndicator()` adds a binary variable indicating if observations are
missing (missing indicator). It adds missing indicators to both categorical and numerical
variables.

You can select the variables for which the missing indicators should be created passing
a variable list to the `variables` parameter. Alternatively, the imputer will
automatically add indicators to all variables.

.. attention::

    **New in version 2.0:** When `variables` is `None`, :class:`MissingIndicator()` used to
    raise an error if the dataframe contained no variables. You can now
    set the new parameter `return_empty` to `True` to make the transformer return an
    empty list of variables and skip adding the missing indicators instead, leaving the dataframe
    unchanged. This lets you reuse the same pipeline across different datasets or
    projects, some of which may not contain variables, without building a
    tailored pipeline for each one. `return_empty` will default to `True` from version
    2.1 onwards.

The imputer has the option to add missing indicators to all variables or only to those
that have missing data in the train set. You can change the behaviour using the
parameter `missing_only`.

If `missing_only=True`, missing indicators will be added only to those variables with
missing data in the train set. This means that if you passed a variable list to
`variables` and some of those variables did not have missing data, no missing indicators
will be added to them. If it is paramount that all variables in your list get their
missing indicators, make sure to set `missing_only=False`.

.. tip::

    It is recommended to use `missing_only=True` when not passing a list of variables to
    impute.

Python implementation
---------------------

Below a code example using the house prices dataset.

First, let's load the data and separate it into train and test:

.. code:: python

    from sklearn.datasets import fetch_openml
    from sklearn.model_selection import train_test_split
    from feature_engine.imputation import MissingIndicator

    # Load dataset
    data = fetch_openml(name='house_prices', as_frame=True)
    data = data.frame

    # Separate into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(
        data.drop(['Id', 'SalePrice'], axis=1),
        data['SalePrice'],
        test_size=0.3,
        random_state=0)


Now we set up the imputer to add missing indicators to the 4 indicated variables:

.. code:: python

    # set up the imputer
    addBinary_imputer = MissingIndicator(
        variables=['Alley', 'MasVnrType', 'LotFrontage', 'MasVnrArea'],
    )

    # fit the imputer
    addBinary_imputer.fit(X_train)

Because we left the default value for `missing_only`, :class:`MissingIndicator()`
will check if the variables indicated above have missing data in X_train. If they do,
missing indicators will be added for all 4 variables looking forward. If one of them
had not had missing data in X_train, missing indicators would have been added to the
remaining 3 variables only.

We can know which variables will have missing indicators by looking at the variable list
in :class:`MissingIndicator()`'s attribute `variables_`.

Now, we can go ahead and add the missing indicators:

.. code:: python

	# transform the data
	train_t = addBinary_imputer.transform(X_train)
	test_t = addBinary_imputer.transform(X_test)

	train_t[['Alley_na', 'MasVnrType_na', 'LotFrontage_na', 'MasVnrArea_na']].head()

In the following image, we se the result of the previous code, that is, the missing
indicators that were added to the dataframe:

.. image:: ../../images/missingindicator.png
   :width: 500

Note that after adding missing indicators, we still need to replace NA in the original
variables if we plan to use them to train machine learning models.

Considerations
--------------

Missing indicators are commonly used alongside random sampling, mean or median
imputation, or frequent category imputation.

Additional resources
--------------------

For tutorials about missing data imputation methods check out these resources:

- `Feature Engineering for Machine Learning <https://www.trainindata.com/p/feature-engineering-for-machine-learning>`_, online course.
- `Feature Engineering for Time Series Forecasting <https://www.trainindata.com/p/feature-engineering-for-forecasting>`_, online course.
- `Python Feature Engineering Cookbook <https://www.packtpub.com/en-us/product/python-feature-engineering-cookbook-9781835883587>`_, book.

Both our book and courses are suitable for beginners and more advanced data scientists
alike. By purchasing them you are supporting `Sole <https://linkedin.com/in/soledad-galli>`_,
the main developer of feature-engine.